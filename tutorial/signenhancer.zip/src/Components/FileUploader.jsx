import React from "react";

export default function FileUploader(props) {
  const hiddenFileInput = React.useRef(null);

  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };
  const handleChange = (event) => {
    const fileUploaded = event.target.files;
    props.handleFile(fileUploaded);
  };
  return (
    <div className="my-11">
      <input
        type="file"
        multiple
        ref={hiddenFileInput}
        onChange={handleChange}
        style={{ display: "none" }}
      />
      <span
        style={{ backgroundColor: "#AF89F4" }}
        onClick={handleClick}
        className="font-poppins font-medium  text-white text-md px-10 p-3 mt-5 rounded-full hover:opacity-60"
      >
        Choose Files
      </span>
    </div>
  );
}
