const Progress_bar = ({ progress }) => {
  return (
    <div
      style={{ backgroundColor: "#261741" }}
      className="h-12 w-2/3 rounded-full "
    >
      <div
        style={{ width: `${progress}%`, backgroundColor: "#B18BF6" }}
        className="h-full rounded-full flex items-center justify-end text-right"
      >
        <span
          style={{ color: "#261741" }}
          className="p-3 font-extrabold"
        >{`${progress}%`}</span>
      </div>
    </div>
  );
};

export default Progress_bar;
