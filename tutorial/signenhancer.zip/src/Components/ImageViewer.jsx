import React from "react";
import { FaTimes, FaDownload } from "react-icons/fa";
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";

export default function ImageViewer(openImageViewer, closeFunction) {
  return (
    <div
      style={{ backgroundColor: "rgba(0, 0, 0, 0.7)" }}
      className="flex justify-center flex-col items-center fixed w-full h-full top-0 left-0 right-0 bottom-0 z-10"
    >
      <div className="h-full w-full flex items-center justify-center ">
        <FaTimes
          size={35}
          color={"white"}
          className="m-3 absolute top-10 right-10"
          onClick={closeFunction}
        />
        <TransformWrapper>
          <TransformComponent>
            <div
              style={{
                width: screen.width / 2,
                height: screen.width / 3,
              }}
              className="items-center flex "
            >
              <img
                src={openImageViewer.data.src}
                className="w-full"
                alt="test"
              />
            </div>
          </TransformComponent>
        </TransformWrapper>
      </div>
      <div className="w-full h-10 bg-red-50 justify-around flex flex-row items-center">
        <div className="font-semibold text-2xl font-Poppins">
          {openImageViewer.heading}
        </div>
        <div className="font-bold text-md font-Poppins">
          Size : {openImageViewer.data.size}
        </div>
        <div className="font-bold text-md font-Poppins">
          Resolution : {openImageViewer.data.res}
        </div>
        <a download target="_blank" href={openImageViewer.data.src}>
          <FaDownload size={25} color={"black"} />
        </a>
      </div>
    </div>
  );
}
