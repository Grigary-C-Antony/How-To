import React, { useState } from "react";
import { FaArrowLeft } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import ImageViewer from "../Components/ImageViewer";

export default function ResultPage() {
  const navigate = useNavigate();
  const [openImageViewer, setOpenImageViewer] = useState(false);

  let options = ["Processed Images", "Exceptional Images", "Compared Images"];
  let fullData = [
    {
      title: "Processed Images",
      data: [
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/502",
          },
          processed: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/40",
          },
        },
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/503",
          },
          processed: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/42",
          },
        },
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/505",
          },
          processed: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/41",
          },
        },
      ],
    },
    {
      title: "Exceptional Images",
      data: [
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/502",
          },
        },
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/503",
          },
        },
        {
          original: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/505",
          },
        },
      ],
    },
    {
      title: "Compared Images",
      data: [
        {
          processed: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/185/48",
          },
          processed2: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/40",
          },
        },
        {
          processed: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/187/42",
          },
          processed2: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/42",
          },
        },
        {
          processed: {
            size: "1.5MB",
            res: "6565 X 5858",
            src: "https://picsum.photos/186/41",
          },
          processed2: {
            size: "4.2KB",
            res: "185 X 40",
            src: "https://picsum.photos/185/41",
          },
        },
      ],
    },
  ];

  const refs = options.reduce((acc, value) => {
    acc[value] = React.createRef();
    return acc;
  }, {});

  const handleClick = (id) =>
    refs[id].current.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });

  return (
    <div>
      {openImageViewer ? (
        ImageViewer(openImageViewer, () => {
          setOpenImageViewer(null);
        })
      ) : (
        <div></div>
      )}
      <div
        onClick={() => {
          navigate("/");
        }}
        style={{ backgroundColor: "#4E415F" }}
        className="h-14 w-14 absolute left-10 top-10 bg-violet-800 hover:opacity-50 items-center justify-center flex rounded-full"
      >
        <FaArrowLeft size={25} color={"white"} />
      </div>
      <div className="justify-center flex mt-32">
        {options.map((element, index) => {
          return (
            <div
              onClick={() => handleClick(element)}
              key={index}
              className="px-10 py-5 mx-10 hover:opacity-50 rounded-xl result-main-buttons"
            >
              <span className="font-poppins font-bold text-black text-md ">
                {element}
              </span>
            </div>
          );
        })}
      </div>
      <div className="mt-10">
        {fullData.map((element, index) => {
          return (
            <div ref={refs[element.title]} key={index} className="mt-10">
              <span className="ml-20 font-semibold text-2xl font-Poppins ">
                {element.title}
              </span>
              <div className="flex flex-col items-center ">
                {element?.data?.map((element, index) => {
                  return (
                    <div
                      key={index}
                      className="w-10/12 h-60 mt-8 bg-white rounded-2xl result-main-buttons flex-row flex"
                    >
                      <div
                        style={{ backgroundColor: "#4E415F" }}
                        className="w-1/12 h-60 absolute bg-black rounded-l-2xl result-main-buttons"
                      ></div>
                      <div className="flex-row flex w-full justify-center  self-center ml-30">
                        {element.original ? (
                          <div className="flex-row flex ">
                            <div className="flex-col flex self-center ml-20">
                              <span className="font-poppins font-normal text-black text-lg">
                                Original Image
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                {" "}
                                Size : {element.original.size}
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                {element.original.res} px
                              </span>
                            </div>
                            <div className="h-44 w-44 self-center ml-10">
                              <img
                                onClick={() =>
                                  setOpenImageViewer({
                                    data: element.original,
                                    heading: "Original Image",
                                  })
                                }
                                className="rounded-2xl "
                                src={element.original.src}
                                alt=""
                              />
                            </div>
                          </div>
                        ) : (
                          <div></div>
                        )}
                        {element.processed ? (
                          <div className="flex-row flex">
                            <div className="flex-col flex self-center ml-20">
                              <span className="font-poppins font-normal text-black text-lg">
                                Processed Image
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                Size : {element.processed.size}
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                {element.processed.res} px
                              </span>
                            </div>
                            <div className="h-44 w-44 self-center ml-10 border-2 rounded-2xl flex items-center">
                              <img
                                onClick={() =>
                                  setOpenImageViewer({
                                    data: element.processed,
                                    heading: "Processed Image",
                                  })
                                }
                                className=""
                                src={element.processed.src}
                                alt=""
                              />
                            </div>
                          </div>
                        ) : (
                          <div></div>
                        )}
                        {element.processed2 ? (
                          <div className="flex-row flex">
                            <div className="flex-col flex self-center ml-20">
                              <span className="font-poppins font-normal text-black text-lg">
                                Processed Image
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                Size : {element.processed2.size}
                              </span>
                              <span className="font-poppins font-bold text-black text-base">
                                {element.processed2.res} px
                              </span>
                            </div>
                            <div className="h-44 w-44 self-center ml-10 border-2 rounded-2xl flex items-center">
                              <img
                                className=""
                                onClick={() =>
                                  setOpenImageViewer({
                                    data: element.processed2,
                                    heading: "Processed Image",
                                  })
                                }
                                src={element.processed2.src}
                                alt=""
                              />
                            </div>
                          </div>
                        ) : (
                          <div></div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        <div className="mt-10" />
      </div>
    </div>
  );
}
