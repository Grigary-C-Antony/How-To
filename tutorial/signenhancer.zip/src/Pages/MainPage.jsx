import React, { useEffect } from "react";
import mainImage from "../assets/5178414.png";
import FileUploader from "../Components/FileUploader";
import Progress_bar from "../Components/ProgressBar";
import { useNavigate } from "react-router-dom";
let interval = undefined;
export default function () {
  const navigate = useNavigate();
  const [imagesList, setImagesList] = React.useState();
  const [loading, setLoading] = React.useState(false);
  const [progress, setProgress] = React.useState(0);

  useEffect(() => {
    if (loading) {
      interval = setInterval(() => {
        setProgress((prev) => {
          return prev + 100 / imagesList.length;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
  }, [loading]);
  useEffect(() => {
    if (progress >= 100) {
      setLoading(false);
      clearInterval(interval);
      navigate("/result");
    }
  }, [progress]);

  const handleProcess = () => {
    setLoading(true);
    //TODO:change this to axios
    setTimeout(() => {
      setProgress(95);
    }, 30000);
    //TODO:change this to axios
  };

  return (
    <div className="mainBackground flex min-h-screen justify-between">
      <div className="w-7/12 items-center flex">
        {imagesList ? (
          <div
            style={{ backgroundColor: "#FFECEF" }}
            className="w-full h-full "
          >
            {loading ? (
              <div
                style={{ backgroundColor: "rgba(255, 255, 255, 0.3)" }}
                className=" flex fixed w-7/12 h-full items-center justify-center z-10"
              >
                <Progress_bar progress={Math.round(progress)} />
              </div>
            ) : (
              <div></div>
            )}
            <div>
              <div className="mt-10">
                <div className="items-center flex justify-around p-5">
                  <div className="font-Poppins font-bold w-20">Sl No</div>
                  <div className="font-Poppins font-bold w-48">File Name</div>
                  <div className="font-Poppins font-bold ">Image</div>
                </div>
                <div className="overflow-auto h-96">
                  {imagesList?.map((element, index) => {
                    return (
                      <div
                        className="items-center flex justify-around mt-8"
                        key={index}
                      >
                        <div className="font-Poppins font-bold ">
                          {" "}
                          {index + 1}
                        </div>
                        <div className="truncate w-48 font-Poppins font-bold">
                          {element.name}
                        </div>

                        <div className="w-10 h-10">
                          <img
                            className="w-full h-full"
                            src={URL.createObjectURL(element)}
                            alt=""
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="flex items-center justify-around mt-12">
                <span className="font-Poppins font-bold">Cancel</span>
                <div className="">
                  <span
                    style={{
                      border: "2px solid #7A5DAF",
                      color: "#7A5DAF",
                    }}
                    className="font-poppins font-bold text-lg px-14 p-2 mt-5 rounded-full hover:opacity-60"
                    onClick={handleProcess}
                  >
                    Process
                  </span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className=" ml-32">
            <div className="font-poppins font-bold text-white text-6xl leading-tight tracking-wider">
              Sign <br /> Enhancer
            </div>
            <div className="font-poppins font-normal text-white text-xl tracking-wider">
              To get started use the button below and <br />
              select files to enhance your signature
            </div>
            <FileUploader
              handleFile={(e) => {
                setImagesList([...e]);
                console.log([...e]);
              }}
            />
            <div className="font-poppins font-normal text-white text-sm mt-32">
              Need help?
            </div>
          </div>
        )}
      </div>
      <div className="w-5/12 items-center justify-center flex">
        <img className="w-full" src={mainImage} />
      </div>
    </div>
  );
}
